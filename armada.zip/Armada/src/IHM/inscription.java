package IHM;

public class inscription {

}
